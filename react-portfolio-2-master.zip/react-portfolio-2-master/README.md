# Personal Portfolio Website
This project is one of the results of my journey learning frontend with react.

# Preview
[Live Preview Here](https://dama.ink)

![screencapture-dama-ink-2023-01-24-23_26_46](https://user-images.githubusercontent.com/73756341/214350319-3ff139fa-4150-4488-b6ca-52e2ae2caec3.png)
