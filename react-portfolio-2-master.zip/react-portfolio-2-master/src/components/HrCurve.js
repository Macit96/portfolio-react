import hr from '../assets/curve-hr.svg'
export default function HrCurve(){
    return (
        <img src={hr} className="w-full md:h-3 mt-8" alt="hr" />
    )
}